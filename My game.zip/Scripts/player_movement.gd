extends CharacterBody3D

var ORIGINAL_SPEED: float
var SPEED: float = 5.0
var SPRINT_SPEED: float = 7.5 # Script formatting speed profile variable updated

const JUMP_VELOCITY = 4.5

func _ready() -> void:
	ORIGINAL_SPEED = SPEED

func _physics_process(delta: float) -> void:
	# Add the gravity vector dynamics smoothly
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle mobile jump integration directly
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Sprint dynamic handling mechanism optimization
	if Input.is_action_pressed("sprint"): # Mobile continuous active handling loop
		SPEED = SPRINT_SPEED
	else:
		SPEED = ORIGINAL_SPEED

	# Vector mapping variables synchronized perfectly with the UI Controller action strings
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	
	# Camera horizontal alignment context generation vector parsing
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	
	if direction:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
	else:
		# Smooth deceleration to avoid violent twitch stopping mechanics
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)

	move_and_slide()
