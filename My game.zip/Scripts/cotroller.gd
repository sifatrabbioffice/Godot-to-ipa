extends Control

@export var max_range: float = 140.0       # বড় সাইজ জয়েস্টিকের জন্য রেঞ্জ বাড়ানো হয়েছে
@export var deadzone: float = 0.15
@export var lock_threshold: float = 120.0  # কত পিক্সেল নিচে টানলে লক অ্যাক্টিভ হবে

# AAA Mobile UI Color Palette (Translucent Glassmorphism)
const COLOR_PAD_DARK   = Color(0.08, 0.08, 0.1, 0.25)  # ইমেজের মতো হালকা ট্রান্সপারেন্ট ব্ল্যাক
const COLOR_GLOW_BLUE  = Color(0.0, 0.4, 0.9, 0.5)    # অ্যাক্টিভ জয়েস্টিক গ্লো
const COLOR_SYM_WHITE  = Color(0.9, 0.9, 0.9, 0.6)    # ইমেজের মতো সফট হোয়াইট আইকন
const COLOR_BORDER     = Color(1.0, 1.0, 1.0, 0.12)   # সূক্ষ্ম বর্ডার লাইন্স

var l_track_id: int = -1
var r_track_id: int = -1

var l_base_center: Vector2
var r_base_center: Vector2
var l_stick_pos: Vector2
var r_stick_pos: Vector2

# লক ফিচারের জন্য স্টেট ট্র্যাকিং ভেরিয়েবল
var l_is_locked: bool = false
var r_is_locked: bool = false

var button_rects: Dictionary = {}
var active_buttons: Dictionary = {}

func _ready() -> void:
	anchor_right = 1.0
	anchor_bottom = 1.0
	grow_horizontal = Control.GROW_DIRECTION_BOTH
	grow_vertical = Control.GROW_DIRECTION_BOTH
	mouse_filter = MOUSE_FILTER_STOP
	
	var canvas = CanvasLayer.new()
	canvas.layer = 100
	get_parent().call_deferred("add_child", canvas)
	reparent(canvas)
	
	await get_tree().process_frame
	_calculate_layout()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		_calculate_layout()

func _calculate_layout() -> void:
	# স্ক্রিন সাইজের ওপর ভিত্তি করে ইমেজের মতো পারফেক্ট বড় সাইজ প্লেসমেন্ট
	var pad_size: float = 500.0 
	
	l_base_center = Vector2(pad_size, size.y - pad_size + 40)
	l_stick_pos = l_base_center
	var dpad_center = Vector2(pad_size, size.y - pad_size - 220)
	
	r_base_center = Vector2(size.x - pad_size, size.y - pad_size + 40)
	r_stick_pos = r_base_center
	var face_center = Vector2(size.x - pad_size, size.y - pad_size - 220)
	
	button_rects = {
		# টপ লেফট এবং রাইট বাটন (L2, L1, R2, R1)
		"aim":           Rect2(Vector2(pad_size - 120, 80), Vector2(300, 160)),     # L2
		"grenade":       Rect2(Vector2(pad_size - 120, 250), Vector2(250, 130)),    # L1
		"fire":          Rect2(Vector2(size.x - pad_size + 10, 80), Vector2(300, 160)),  # R2
		"melee":         Rect2(Vector2(size.x - pad_size + 60, 250), Vector2(250, 130)), # R1
		
		# D-PAD বাটন লেআউট
		"dpad_up":       Rect2(dpad_center + Vector2(0, -65) - Vector2(30, 30), Vector2(60, 60)),
		"dpad_down":     Rect2(dpad_center + Vector2(0, 65) - Vector2(30, 30), Vector2(60, 60)),
		"dpad_left":     Rect2(dpad_center + Vector2(-65, 0) - Vector2(30, 30), Vector2(60, 60)),
		"dpad_right":    Rect2(dpad_center + Vector2(65, 0) - Vector2(30, 30), Vector2(60, 60)),
		
		# অ্যাকশন বাটন লেআউট (PS5 স্টাইল ক্রস, সার্কেল, স্কয়ার, ট্রায়াঙ্গেল)
		"weapon_swap":   Rect2(face_center + Vector2(0, -65) - Vector2(35, 35), Vector2(70, 70)),   # Triangle
		"jump":          Rect2(face_center + Vector2(0, 65) - Vector2(35, 35), Vector2(70, 70)),    # Cross
		#"interact":      Rect2(face_center + Vector2(-65, 0) - Vector2(35, 35), Vector2(70, 70)),   # Square
		"sprint":      Rect2(face_center + Vector2(-65, 0) - Vector2(35, 35), Vector2(70, 70)),   # Square
		"crouch":        Rect2(face_center + Vector2(65, 0) - Vector2(35, 35), Vector2(70, 70)),    # Circle
		
		# সেন্টার কন্ট্রোলস
		"ps_home":       Rect2(Vector2(size.x / 2 - 80, size.y - 100), Vector2(65, 65)),
		"ps_options":    Rect2(Vector2(size.x / 2 + 15, size.y - 100), Vector2(65, 65))
	}
	queue_redraw()

func _draw() -> void:
	# ব্যাকগ্রাউন্ড বড় অ্যানালগ প্যাড ড্রয়িং
	_draw_pro_joystick(l_base_center, l_stick_pos, "L", l_is_locked)
	_draw_pro_joystick(r_base_center, r_stick_pos, "R", r_is_locked)
	
	# ইমেজের রাইট সাইডের বাটনগুলোর পেছনের বড় ব্ল্যাক সার্কেল ব্যাকগ্রাউন্ড
	var face_center = Vector2(size.x - 500.0, size.y - 500.0 - 220)
	draw_circle(face_center, 0.0, COLOR_PAD_DARK)
	draw_circle(face_center, 0.0, COLOR_BORDER, false, 1.5)

	for action in button_rects:
		var rect: Rect2 = button_rects[action]
		var is_pressed = active_buttons.has(action)
		
		var fill = COLOR_GLOW_BLUE if is_pressed else Color(0, 0, 0, 0.0)
		var border = Color.WHITE if is_pressed else COLOR_BORDER
		
		if action.begins_with("dpad_"):
			# D-Pad বডি ইমেজের মতো মার্জড দেখাতে ব্যাকগ্রাউন্ড ড্র করা হয়নি, শুধু ডিরেকশন শেপ
			_draw_dpad_arrows(rect, action, is_pressed)
		elif action in ["aim", "fire", "grenade", "melee"]:
			draw_style_box(_get_rounded_box(COLOR_PAD_DARK if !is_pressed else fill, border, 15), rect)
			var label_text = ""
			match action:
				"aim": label_text = "L2"
				"fire": label_text = "R2"
				"grenade": label_text = "L1"
				"melee": label_text = "R1"
			_draw_string_label(rect, label_text)
		elif action in ["ps_home", "ps_options"]:
			draw_style_box(_get_rounded_box(COLOR_PAD_DARK if !is_pressed else fill, border, 18), rect)
			if action == "ps_home":
				_draw_menu_lines(rect.get_center(), false)
			else:
				_draw_menu_lines(rect.get_center(), true)
		else:
			var btn_c = rect.get_center()
			if is_pressed:
				draw_circle(btn_c, rect.size.x / 2.0, fill)
			_draw_ps5_symbols(btn_c, action)

func _draw_pro_joystick(base: Vector2, stick: Vector2, label: String, is_locked: bool) -> void:
	# বড় জয়েস্টিক রিং (ইমেজের সাথে হুবহু মিল রেখে সাইজ ২২০ করা হয়েছে)
	draw_circle(base, 120.0, COLOR_PAD_DARK)
	draw_circle(base, 100.0, COLOR_BORDER, false, 2.0)
	
	# ইনার গাইড রিং
	draw_circle(base, 170.0, Color(1, 1, 1, 0.02), false, 1.0)
	
	# লক ইন্ডিকেটর ভিজ্যুয়াল (নিচের দিকে লক জোন হাইলাইট)
	if is_locked:
		var lock_sign_pos = base + Vector2(0, max_range)
		draw_circle(lock_sign_pos, 15.0, COLOR_GLOW_BLUE)
	
	# জয়েস্টিক নব বা নিপল
	var stick_fill = COLOR_GLOW_BLUE if (stick != base or is_locked) else Color(0.15, 0.15, 0.18, 0.6)
	var stick_stroke = Color.WHITE if (stick != base or is_locked) else COLOR_BORDER
	
	# থ্রিডি ইফেক্টের জন্য ইনার শ্যাডো সার্কেল
	draw_circle(stick, 90.0, stick_fill)
	draw_circle(stick, 90.0, stick_stroke, false, 2.0)
	
	_draw_label_inside(stick, label)

func _get_rounded_box(fill: Color, border: Color, radius: int) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = fill
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	return sb

func _draw_ps5_symbols(center: Vector2, action: String) -> void:
	# ইমেজের কালার কোড অনুযায়ী বাটন সিম্বল (Blue, Pink, Green, Red)
	match action:
		"jump": # Cross (X) - Blue
			var c = Color(0.4, 0.55, 0.9, 0.8)
			draw_line(center + Vector2(-12, -12), center + Vector2(12, 12), c, 4.0, true)
			draw_line(center + Vector2(-12, 12), center + Vector2(12, -12), c, 4.0, true)
		"crouch": # Circle (O) - Red
			var c = Color(0.9, 0.4, 0.4, 0.8)
			draw_arc(center, 14.0, 0, TAU, 32, c, 4.0, true)
		"weapon_swap": # Triangle - Green
			var c = Color(0.4, 0.8, 0.6, 0.8)
			var p1 = center + Vector2(0, -15)
			var p2 = center + Vector2(-15, 12)
			var p3 = center + Vector2(15, 12)
			draw_line(p1, p2, c, 4.0, true)
			draw_line(p2, p3, c, 4.0, true)
			draw_line(p3, p1, c, 4.0, true)
		#"interact": # Square - Pink
		"sprint": # Square - Pink
			var c = Color(0.9, 0.5, 0.7, 0.8)
			var sq_rect = Rect2(center - Vector2(12, 12), Vector2(24, 24))
			draw_rect(sq_rect, c, false, 4.0)

func _draw_dpad_arrows(rect: Rect2, action: String, is_pressed: bool) -> void:
	var c = rect.get_center()
	var col = Color.WHITE if is_pressed else COLOR_SYM_WHITE
	
	# সলিড ট্রায়াঙ্গেল ডি-প্যাড আইকন ডিজাইন
	var points = PackedVector2Array()
	match action:
		"dpad_up":
			points.append_array([c + Vector2(0, -14), c + Vector2(-14, 2), c + Vector2(14, -2)])
		"dpad_down":
			points.append_array([c + Vector2(0, 14), c + Vector2(-14, -2), c + Vector2(14, -2)])
		"dpad_left":
			points.append_array([c + Vector2(-14, 0), c + Vector2(2, -14), c + Vector2(2, 14)])
		"dpad_right":
			points.append_array([c + Vector2(14, 0), c + Vector2(-2, -14), c + Vector2(-2, 14)])
	draw_polygon(points, [col])

func _draw_menu_lines(center: Vector2, is_square: bool) -> void:
	if not is_square:
		# তিন লাইনের মেনু আইকন
		draw_line(center + Vector2(-12, -6), center + Vector2(12, -6), COLOR_SYM_WHITE, 3.5, true)
		draw_line(center + Vector2(-12, 0), center + Vector2(12, 0), COLOR_SYM_WHITE, 3.5, true)
		draw_line(center + Vector2(-12, 6), center + Vector2(12, 6), COLOR_SYM_WHITE, 3.5, true)
	else:
		# স্কয়ার মেনু আইকন
		var sq = Rect2(center - Vector2(10, 10), Vector2(20, 20))
		draw_rect(sq, COLOR_SYM_WHITE, false, 3.5)

func _draw_label_inside(center: Vector2, txt: String) -> void:
	var col = COLOR_SYM_WHITE
	if txt == "L":
		draw_line(center + Vector2(-8, -10), center + Vector2(-8, 10), col, 4.5, true)
		draw_line(center + Vector2(-8, 10), center + Vector2(6, 10), col, 4.5, true)
	elif txt == "R":
		draw_line(center + Vector2(-8, -10), center + Vector2(-8, 10), col, 4.5, true)
		draw_line(center + Vector2(-8, -10), center + Vector2(6, -10), col, 4.5, true)
		draw_line(center + Vector2(6, -10), center + Vector2(6, 0), col, 4.5, true)
		draw_line(center + Vector2(-8, 0), center + Vector2(6, 0), col, 4.5, true)
		draw_line(center + Vector2(-1, 0), center + Vector2(7, 10), col, 4.5, true)

func _draw_string_label(rect: Rect2, label: String) -> void:
	var center = rect.get_center()
	# টেক্সট শেপ ড্রয়িং প্রফেশনাল ভেক্টর লাইনে কনভার্ট করা হয়েছে
	if label.begins_with("L"):
		draw_line(center + Vector2(-14, -9), center + Vector2(-14, 9), COLOR_SYM_WHITE, 4.0, true)
		draw_line(center + Vector2(-14, 9), center + Vector2(-4, 9), COLOR_SYM_WHITE, 4.0, true)
	else:
		draw_line(center + Vector2(-14, -9), center + Vector2(-14, 9), COLOR_SYM_WHITE, 4.0, true)
		draw_line(center + Vector2(-14, -9), center + Vector2(-4, -9), COLOR_SYM_WHITE, 4.0, true)
		draw_line(center + Vector2(-4, -9), center + Vector2(-4, 0), COLOR_SYM_WHITE, 4.0, true)
		draw_line(center + Vector2(-14, 0), center + Vector2(-4, 0), COLOR_SYM_WHITE, 4.0, true)
		draw_line(center + Vector2(-8, 0), center + Vector2(-2, 9), COLOR_SYM_WHITE, 4.0, true)
		
	if label.ends_with("1"):
		draw_line(center + Vector2(8, -9), center + Vector2(8, 9), COLOR_SYM_WHITE, 4.0, true)
	else:
		draw_line(center + Vector2(4, -9), center + Vector2(12, -9), COLOR_SYM_WHITE, 3.5, true)
		draw_line(center + Vector2(12, -9), center + Vector2(12, 0), COLOR_SYM_WHITE, 3.5, true)
		draw_line(center + Vector2(12, 0), center + Vector2(4, 9), COLOR_SYM_WHITE, 3.5, true)
		draw_line(center + Vector2(4, 9), center + Vector2(14, 9), COLOR_SYM_WHITE, 3.5, true)

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_process_touch_down(event.position, event.index)
		else:
			_process_touch_up(event.index)
		accept_event()
		
	elif event is InputEventScreenDrag:
		_process_drag(event.position, event.index)
		accept_event()

func _process_touch_down(pos: Vector2, index: int) -> void:
	for action in button_rects:
		if button_rects[action].has_point(pos):
			active_buttons[action] = index
			Input.action_press(action, 1.0)
			queue_redraw()
			return
			
	# কোনো জয়েস্টিক লক করা থাকলে যেকোনো নতুন টাচ পেলেই তার লক রিলিজ হয়ে যাবে
	if l_is_locked and pos.distance_to(l_base_center) < 220.0:
		l_is_locked = false
		l_track_id = index
		_update_stick(pos, true)
		return
	if r_is_locked and pos.distance_to(r_base_center) < 220.0:
		r_is_locked = false
		r_track_id = index
		_update_stick(pos, false)
		return

	if pos.distance_to(l_base_center) < 220.0 and l_track_id == -1:
		l_track_id = index
		_update_stick(pos, true)
	elif pos.distance_to(r_base_center) < 220.0 and r_track_id == -1:
		r_track_id = index
		_update_stick(pos, false)

func _process_drag(pos: Vector2, index: int) -> void:
	if index == l_track_id:
		_update_stick(pos, true)
	elif index == r_track_id:
		_update_stick(pos, false)

func _process_touch_up(index: int) -> void:
	if index == l_track_id:
		l_track_id = -1
		# টাচ ছেড়ে দেওয়ার সময় চেক করা হচ্ছে নবটি নিচের দিকে লকিং জোনে ছিল কিনা
		var current_offset = l_stick_pos - l_base_center
		if current_offset.y > lock_threshold and abs(current_offset.x) < 60.0:
			l_is_locked = true
			l_stick_pos = l_base_center + Vector2(0, max_range) # লকড পজিশনে আটকে থাকবে
		else:
			l_stick_pos = l_base_center
			_clear_actions(["move_left", "move_right", "move_forward", "move_back"])
			
	elif index == r_track_id:
		r_track_id = -1
		var current_offset = r_stick_pos - r_base_center
		if current_offset.y > lock_threshold and abs(current_offset.x) < 60.0:
			r_is_locked = true
			r_stick_pos = r_base_center + Vector2(0, max_range)
		else:
			r_stick_pos = r_base_center
			_clear_actions(["look_left", "look_right", "look_up", "look_down"])
		
	for action in active_buttons.keys():
		if active_buttons[action] == index:
			active_buttons.erase(action)
			Input.action_release(action)
	queue_redraw()

func _update_stick(touch_pos: Vector2, is_left: bool) -> void:
	var base = l_base_center if is_left else r_base_center
	var offset = touch_pos - base
	
	if offset.length() > max_range:
		offset = offset.normalized() * max_range
		
	if is_left:
		l_stick_pos = base + offset
	else:
		r_stick_pos = base + offset
		
	var out = offset / max_range
	if out.length() < deadzone: 
		out = Vector2.ZERO
		
	var actions = ["move_left", "move_right", "move_forward", "move_back"] if is_left else ["look_left", "look_right", "look_up", "look_down"]
	_inject_axis(out, actions)
	queue_redraw()

func _inject_axis(vec: Vector2, acts: Array) -> void:
	# এক্সিস ইনজেকশন ভ্যালু জেনারেট করে ইনপুট ম্যাপে সেন্ড করে
	if vec.x < 0:
		Input.action_press(acts[0], abs(vec.x))
		Input.action_release(acts[1])
	elif vec.x > 0:
		Input.action_press(acts[1], vec.x)
		Input.action_release(acts[0])
	else:
		Input.action_release(acts[0])
		Input.action_release(acts[1])

	if vec.y < 0:
		Input.action_press(acts[2], abs(vec.y))
		Input.action_release(acts[3])
	elif vec.y > 0:
		Input.action_press(acts[3], vec.y)
		Input.action_release(acts[2])
	else:
		Input.action_release(acts[2])
		Input.action_release(acts[3])

func _clear_actions(acts: Array) -> void:
	for a in acts: 
		Input.action_release(a)
